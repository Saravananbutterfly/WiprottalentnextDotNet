﻿using System.ComponentModel.DataAnnotations;

namespace ProductApp.Models
{
    public class Product
    {
        [Required]
        public int ProductID { get; set; }

        [Required, StringLength(100)]
        public string ProductName { get; set; }

        [StringLength(255)]
        public string Description { get; set; }

        [Required, Range(1, 1000)]
        public int Quantity { get; set; }

        [Required, Range(0.01, 10000)]
        public decimal UnitPrice { get; set; }

        [Required, Range(1, 500)]
        public int ReOrderLevel { get; set; }
    }
}
