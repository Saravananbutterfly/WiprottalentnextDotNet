using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using ProductApp.Models;

namespace ProductApp.Pages
{
    public class NewProductModel : PageModel
    {
        [BindProperty]
        public Product Product { get; set; }

        public void OnGet() { }

        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            // Simulating database save (In a real app, save to DB)
            TempData["Message"] = $"Product '{Product.ProductName}' added successfully!";
            return RedirectToPage("Success");
        }
    }
}
